//
//  MewViewController.swift
//  Pokemon iOS
//
//  Created by David Fernandes on 20/12/2021.
//

import UIKit

class MewViewController : UIViewController {

    @IBAction func mewtocharmander(_ sender: Any) {
        self.performSegue(withIdentifier: "mewtocharmander", sender: self)
        
    }
    
    @IBAction func mewtobarbasaur(_ sender: Any) {
        self.performSegue(withIdentifier: "mewtobarbasaur", sender: self)
    }
    
    @IBAction func mewtoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "mewtoarena", sender: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}

