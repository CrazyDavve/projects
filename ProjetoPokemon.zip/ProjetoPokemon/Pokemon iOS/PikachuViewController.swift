//
//  PikachuViewController.swift
//  Pokemon iOS
//
//  Created by David Fernandes on 21/12/2021.
//

import UIKit

class PikachuViewController: UIViewController {
    
    @IBAction func pikatutosquirtle(_ sender: Any) {
        self.performSegue(withIdentifier: "pikatutosquirtle", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func pikachutocharmander(_ sender: Any) {
        self.performSegue(withIdentifier: "pikachutocharmander", sender: self)
    }
    
    @IBAction func pikachutoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "pikachutoarena", sender: self)
    }
}
