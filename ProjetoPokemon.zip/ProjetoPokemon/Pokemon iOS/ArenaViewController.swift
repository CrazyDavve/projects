//
//  ArenaViewController.swift
//  Pokemon iOS
//
//  Created David Fernandes on 21/12/2021.
//

import UIKit
import SwiftUI

class ArenaViewController: UIViewController {
    
    @IBAction func arenatocharmander(_ sender: Any) {
        self.performSegue(withIdentifier: "arenatocharmander", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("View has loaded :)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    @IBAction func ola(_ sender: Any) {
        self.performSegue(withIdentifier: "ola", sender: self)
    }
    
    

    
}
