//
//  BarbasaurViewController.swift
//  Pokemon iOS
//
//  Created by David Fernandes on 20/12/2021.
//

import UIKit

class BarbasaurViewController : UIViewController {
    
    @IBAction func barbasaurtomew(_ sender: Any) {
        self.performSegue(withIdentifier: "barbasaurtomew", sender: self)
    }
    
    @IBAction func barbasaurtosquirtle(_ sender: Any) {
        self.performSegue(withIdentifier: "barbasaurtosquirtle", sender: self)
    }
    
    @IBAction func barbasaurtoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "barbasaurtoarena", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}

