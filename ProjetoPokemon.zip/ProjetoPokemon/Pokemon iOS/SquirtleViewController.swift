//
//  SquirtleViewController.swift
//  Pokemon iOS
//
//  Created by David Fernandes on 21/12/2021.
//

import UIKit

class SquirtleViewController: UIViewController {

    
    @IBAction func squirtletobarbasaur(_ sender: Any) {
        self.performSegue(withIdentifier: "squirtletobarbasaur", sender: self)
    }
    
    @IBAction func squirtletopikachu(_ sender: Any) {
        self.performSegue(withIdentifier: "squirtletopikachu", sender: self)
    }
    
    @IBAction func squirtletoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "squirtletoarena", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
