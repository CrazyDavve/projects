//
//  CharmanderViewController.swift
//  Pokemon iOS
//
//  Created by David Fernandes on 20/12/2021.
//

import UIKit
import SwiftUI

class CharmanderViewController : UIViewController {

    @IBAction func charmandertomew(_ sender: Any) {
        self.performSegue(withIdentifier: "charmandertomew", sender: self)
    }
    
    @IBAction func charmandertoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "charmandertoarena", sender: self)
    }
    

    @IBAction func charmandertopikachu(_ sender: Any) {
        self.performSegue(withIdentifier: "charmandertopikachu", sender: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    

    
    struct ArenaViewController: View{
        var body: some View{
    NavigationView{
        NavigationLink(destination: ArenaViewController(), label: {
            Text("Next Screen")
        })
        
        
        
        }
    }
}
    
    
}
    
    

